import fs from "node:fs";
import path from "node:path";
import type { Config, GlobalConfig, PagesConfig } from "./types.js";

export function stringifyToml(obj: any): string {
  function serialize(value: any, prefix = ""): string {
    let result = "";

    if (value === null || value === undefined) {
      return "";
    }

    if (Array.isArray(value)) {
      for (const item of value) {
        result += prefix + serialize(item) + "\n";
      }
      return result;
    }

    if (typeof value === "object") {
      let hasNested = false;
      for (const [key, val] of Object.entries(value)) {
        if (typeof val === "object" && val !== null && !Array.isArray(val)) {
          hasNested = true;
          result += prefix + "[" + key + "]\n";
          result += serialize(val, prefix + "  ");
        }
      }
      if (!hasNested) {
        for (const [key, val] of Object.entries(value)) {
          if (Array.isArray(val)) {
            result += prefix + key + " = [";
            result += val.map(v => typeof v === "string" ? `"${v}"` : String(v)).join(", ");
            result += "]\n";
          } else {
            result += prefix + key + " = " + (typeof val === "string" ? `"${val}"` : String(val)) + "\n";
          }
        }
      }
      return result;
    }

    return typeof value === "string" ? `"${value}"` : String(value);
  }

  return serialize(obj);
}

export { Config, GlobalConfig, PagesConfig };

const getWorkersJsoncPath = () => path.resolve(process.cwd(), "workers.jsonc");
const getPagesJsoncPath = () => path.resolve(process.cwd(), "pages.jsonc");
const getWorkersExamplePath = () => path.resolve(process.cwd(), "workers.jsonc.example");
const getPagesExamplePath = () => path.resolve(process.cwd(), "pages.jsonc.example");

export function parseJsonc(content: string): unknown {
  // Remove single-line comments (only at start of line with optional whitespace)
  let jsonContent = content
    .replace(/^[ \t]*\/\/[^\n]*/gm, "")
    .replace(/\/\*[\s\S]*?\*\//g, "");

  // Fix trailing commas before } or ]
  jsonContent = jsonContent.replace(/,(\s*[}\]])/g, "$1");

  return JSON.parse(jsonContent);
}

export async function loadConfig(): Promise<Config> {
  console.log(`Using JSONC configuration format`);

  const userFile = Bun.file(getWorkersJsoncPath());
  const exampleFile = Bun.file(getWorkersExamplePath());

  let userConfigContent = "";
  if (await userFile.exists()) {
    userConfigContent = await userFile.text();
    console.log(`Loaded configuration from ${getWorkersJsoncPath()}`);
  } else {
    console.warn(`Warning: ${getWorkersJsoncPath()} not found. Using example configuration as base.`);
  }

  if (!await exampleFile.exists()) {
    throw new Error(`Example config file ${getWorkersExamplePath()} not found.`);
  }
  const exampleConfigContent = await exampleFile.text();

  let userConfigObj: Partial<Config> = {};
  if (userConfigContent) {
    try {
      userConfigObj = parseJsonc(userConfigContent) as Partial<Config>;
    } catch (error: unknown) {
      const errorMsg = error instanceof Error ? error.message : String(error);
      throw new Error(`Failed to parse ${getWorkersJsoncPath()}: ${errorMsg}`);
    }
  }

  let exampleConfigObj: Config;
  try {
    const parsedExample = parseJsonc(exampleConfigContent) as Partial<Config>;

    if (typeof parsedExample !== "object" || parsedExample === null) {
      throw new Error(`Example config ${getWorkersExamplePath()} did not parse to an object.`);
    }
    if (!("global" in parsedExample) || !("workers" in parsedExample)) {
      throw new Error(`Example config ${getWorkersExamplePath()} missing required 'global' or 'workers' sections.`);
    }
    exampleConfigObj = parsedExample as Config;
  } catch (error: unknown) {
    const errorMsg = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to parse ${getWorkersExamplePath()}: ${errorMsg}`);
  }

  const mergedConfig: Config = {
    global: { ...(exampleConfigObj.global || {}), ...(userConfigObj.global || {}) } as GlobalConfig,
    workers: { ...(exampleConfigObj.workers || {}) },
  };

  if (userConfigObj.workers) {
    for (const workerName in userConfigObj.workers) {
      if (Object.prototype.hasOwnProperty.call(userConfigObj.workers, workerName)) {
        mergedConfig.workers[workerName] = {
          ...(exampleConfigObj.workers?.[workerName] || {}),
          ...(userConfigObj.workers[workerName] || {}),
        };
      }
    }
  }

  const requiredGlobalKeys: (keyof GlobalConfig)[] = [
    "cloudflare_api_token",
    "cloudflare_account_id",
    "cloudflare_secret_store_id",
    "subdomain_prefix",
  ];

  let missingKeys = false;
  for (const key of requiredGlobalKeys) {
    if (!mergedConfig.global[key]) {
      console.error(`Error: Missing required global configuration key "${key}" in ${getWorkersJsoncPath()} (or example). Please define it.`);
      missingKeys = true;
    }
  }

  if (missingKeys) {
    throw new Error(`Missing required global configuration keys in ${getWorkersJsoncPath()}. Please check the errors above.`);
  }

  return mergedConfig;
}

export async function saveConfig(config: Config): Promise<void> {
  try {
    const content = JSON.stringify(config, null, 2);
    await Bun.file(getWorkersJsoncPath()).write(content);
    console.log(`Configuration saved successfully to ${getWorkersJsoncPath()}`);
  } catch (error: unknown) {
    const errorMsg = error instanceof Error ? error.message : String(error);
    console.error(`Error saving configuration to ${getWorkersJsoncPath()}:`, errorMsg);
    throw new Error(`Failed to save config: ${errorMsg}`);
  }
}

export async function loadPagesConfig(): Promise<{ global: GlobalConfig; pages: Record<string, PagesConfig> }> {
  const pagesFile = Bun.file(getPagesJsoncPath());

  if (!await pagesFile.exists()) {
    console.warn("No pages.jsonc found. Pages config will be empty.");
    return { global: {} as GlobalConfig, pages: {} };
  }

  try {
    const content = await pagesFile.text();
    const parsed = parseJsonc(content);
    return parsed as { global: GlobalConfig; pages: Record<string, PagesConfig> };
  } catch (error: unknown) {
    const errorMsg = error instanceof Error ? error.message : String(error);
    console.warn(`Failed to parse pages.jsonc: ${errorMsg}. Returning empty config.`);
    return { global: {} as GlobalConfig, pages: {} };
  }
}

export async function savePagesConfig(pagesConfig: { global: GlobalConfig; pages: Record<string, PagesConfig> }): Promise<void> {
  try {
    const content = JSON.stringify(pagesConfig, null, 2);
    await Bun.file(getPagesJsoncPath()).write(content);
    console.log(`Pages configuration saved successfully to ${getPagesJsoncPath()}`);
  } catch (error: unknown) {
    const errorMsg = error instanceof Error ? error.message : String(error);
    console.error(`Error saving pages configuration to ${getPagesJsoncPath()}:`, errorMsg);
    throw new Error(`Failed to save pages config: ${errorMsg}`);
  }
}

export async function parseConfig(): Promise<Config> {
  return loadConfig();
}

export async function getWorkerNames(): Promise<string[]> {
  const config = await loadConfig();
  return config.workers ? Object.keys(config.workers) : [];
}